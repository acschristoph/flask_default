class ConnectTimeoutError:
    def __str__(self):
        return "ConnectTimeoutError"

class UnauthorizedError:
    def __str__(self):
        return "ConnectTimeoutError"

class ConnectTimeoutErrorPingOk:
    def __str__(self):
        return "ConnectTimeoutErrorPingOk"

class JsonRpcNotEnabledError:
    def __str__(self):
        return "JsonRpcNotEnabledError"