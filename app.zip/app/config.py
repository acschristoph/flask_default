import os
basedir = os.path.abspath(os.path.dirname(__file__))
import json_log_formatter, logging, datetime

class Config(object):
    SECRET_KEY = 'asfasbtaw35b36betgbesrtzaw'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///' + os.path.join(basedir, 'app.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    LOG_LEVEL = "INFO"
    LOG_FILE = "app.log"
    LOG_FILE_JSON = "app/static/app.json"
    LOG_MAX_BYTES = 30000000
    LOG_BACKUP_COUNT = 5
    LOG_DISABLE_EXISTING_LOGGERS = False
    LOG_WERKZEUG_LEVEL = logging.INFO

class CustomisedJSONFormatter(json_log_formatter.JSONFormatter):
    def json_record(self, message: str, extra: dict, record: logging.LogRecord):
        extra['message'] = message
        extra['level'] = record.levelname
        extra['name'] = record.name

        if 'time' not in extra:
            extra['time'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if record.exc_info:
            extra['exc_info'] = self.formatException(record.exc_info)

        return extra