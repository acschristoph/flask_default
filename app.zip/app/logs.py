import coloredlogs, logging
import logging.config
import app.config

cfg = app.config.Config()

log_config = {
    'version': 1,
    'disable_existing_loggers': cfg.LOG_DISABLE_EXISTING_LOGGERS,   # set True to suppress existing loggers from other modules
    'loggers': {
        '': {
           'level': cfg.LOG_LEVEL,
           'handlers': ['console', 'file', 'json'],
        },
    },
    'formatters': {
        'colored_console': {
           '()': 'coloredlogs.ColoredFormatter', 
           'format': "%(asctime)s - %(name)s - %(levelname)s - %(message)s", 
           'datefmt': '%H:%M:%S'
        },
        'format_for_file': {
           'format': "%(asctime)s %(levelname)s %(funcName)s in %(filename)s (l:%(lineno)d): %(message)s", 
           'datefmt': '%Y-%m-%d %H:%M:%S'
        },
        'format_for_json_file': {
            '()': 'app.config.CustomisedJSONFormatter',
            'format': "%(asctime)s %(levelname)s %(funcName)s in %(filename)s (l:%(lineno)d): %(message)s", 
           'datefmt': '%Y-%m-%d %H:%M:%S'
        }
    },
    'handlers': {
        'console': {
            'level': 'INFO',
            'class': 'logging.StreamHandler',
            'formatter': 'colored_console',
            'stream': 'ext://sys.stdout'
        },
        'file': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'formatter': 'format_for_file',
            'filename': cfg.LOG_FILE,
            'maxBytes': cfg.LOG_MAX_BYTES,
            'backupCount': cfg.LOG_BACKUP_COUNT
        },
        'json': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'formatter': 'format_for_json_file',
            'filename': cfg.LOG_FILE_JSON,
            'maxBytes': cfg.LOG_MAX_BYTES,
            'backupCount': cfg.LOG_BACKUP_COUNT
        }
    }
}

logging.config.dictConfig(log_config)
logger = logging.getLogger(__name__)