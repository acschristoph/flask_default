
import re, logging, json, os
from flask import render_template, flash, redirect, url_for, jsonify, request
from sqlalchemy import exc
from flask_login import current_user, login_user, login_required, logout_user

from app import app, db, login as lm
from app.forms.auth_forms import LoginForm, AddUserForm, ChangeUserForm
from app.models import User

log = logging.getLogger('werkzeug')

log.setLevel(app.config["LOG_WERKZEUG_LEVEL"])

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is None or not user.check_password(form.password.data):
            return redirect(url_for('login'))
        login_user(user, remember=form.remember_me.data)
        return redirect(url_for('index'))
    return render_template('login_form.html', title='Login', form=form)

@lm.unauthorized_handler
def unauthorized_callback():
    return redirect('/login')


@app.route('/')
@app.route('/index')
@login_required
def index():
    return render_template('index.html')

@app.route('/clear-log')
@login_required
def clear_log():
    os.remove(app.config['LOG_FILE_JSON'])
    return redirect("/logs")

@app.route('/get-log')
@login_required
def getlog():
    json_data = []
    with open(app.config['LOG_FILE_JSON']) as file:
        for line in file:
            json_line = json.loads(line)
            json_data.append(json_line)

    json_data.reverse()
    return {"data": json_data}

@app.route('/logs')
@login_required
def logs():
    return render_template('logs.html')

@app.route('/users')
@login_required
def users():
    return render_template('users.html', records=User.query.all())

@app.route('/users-del/<id>')
@login_required
def users_del(id):
   User.query.filter_by(id=id).delete()
   db.session.commit()
   return redirect("/users")

@app.route('/change-pwd/<id>', methods=['GET', 'POST'])
@login_required
def change_user_pwd(id):
    form = ChangeUserForm()
    if form.validate_on_submit():
        user = User.query.filter_by(id=id).first()
        user.set_password(form.password.data)
        db.session.commit()
        flash('Congratulations, password changed!')
        return redirect("/index")
    return render_template('change-pwd.html', title='Change User', form=form)

@app.route('/add-user', methods=['GET', 'POST'])
@login_required
def add_user():
    form = AddUserForm()
    if form.validate_on_submit():
        user = User(username=form.username.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Congratulations, user added!')
        return redirect("users")
    return render_template('user_add.html', title='Add User', form=form)