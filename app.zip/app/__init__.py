from flask import Flask
from app.config import Config
from app.logs import logger
from flask_bootstrap import Bootstrap
from flask_sqlalchemy import SQLAlchemy
from flask_script import Manager
from flask_migrate import Migrate, MigrateCommand
from flask_login import LoginManager
import os, sys

app = Flask(__name__)

app.config.from_object(Config)
Bootstrap(app)
login = LoginManager(app)
login.login_view = 'login'

db = SQLAlchemy(app)
migrate = Migrate(app, db)
manager = Manager(app)
manager.add_command('db', MigrateCommand)

#from app.models import User
#db.create_all()
#admin = User(username='admin')
#admin.set_password('admin')
#db.session.add(admin)
#db.session.commit()

from app import routes, models

logger.info("Started")



